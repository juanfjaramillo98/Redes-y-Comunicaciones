import java.awt.Color;
import java.io.*;
import java.net.*;
import java.util.*;

import javax.net.ssl.SSLServerSocketFactory;

public class Server {

	static final String KEYSTORE_LOCATION = "/Apuesta de Caballos/jks/KeyStore.jks";
	static final String KEYSTORE_PASS = "pass123";
	static final String FINALICE = "Finalice";

	static SSLServerSocketFactory sslServer;
	// private Client cliente;
	static int[] caballos;
	static ArrayList<ClientThread> clientes;
	static int seconds;
	static Random rdm;
//private static AudioUDPServer audio;
	
	public static void main(String[] args) {
		
		System.setProperty("javax.net.ssl.keyStore", KEYSTORE_LOCATION);
		System.setProperty("javax.net.ssl.keyStorePassword", KEYSTORE_PASS);
		sslServer = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
		
		rdm = new Random();
		clientes = new ArrayList<ClientThread>();
		seconds = 0;
		caballos = new int[6];
		
		ServerSocket server = null;

		try {
			//server = sslServer.createServerSocket(1248);
			server = new ServerSocket(1284);
			new Timer().start();
			ServerUDP udp= new ServerUDP();
			udp.start();
			
			// Recibe solicitudes de apostares hasta 3 minutos
			while (seconds < 180) {
				Socket client = server.accept();
				System.out.println("Nuevo cliente para apostar.");
				ClientThread newThread = new ClientThread(client);
				newThread.start();
				clientes.add(newThread);
			}
		
		} catch (Exception e) {
			System.out.println(e.toString());
		} finally {
			try {
				server.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public ArrayList<String[]> leer(String name) throws IOException {
		ArrayList<String[]>elementos=new ArrayList<>();
		FileReader f= new FileReader("baseDatos"+".txt");
		BufferedReader bf = new BufferedReader(f);
		
		String linea= bf.readLine();
		
		while (linea!= null ) {
			String[] ele =null;
			ele= linea.split(" ");
			elementos.add(ele);
			
			System.out.println(elementos+"");
		}
		return elementos;
		
		
	}

	static synchronized void apostar(int caballo, double dinero) {
		caballos[caballo - 1] += dinero;
	}

	static class Timer extends Thread {

		caballo[] caba;

		public Timer() {
			caba = new caballo[6];
			for (int i = 0; i < caba.length; i++) {
				caba[i]= new caballo();
			}
		}

		@Override
		public void run() {
			while (seconds < 180) {
				try {
					Thread.sleep(1000);
					seconds++;
					nuevoSegundo();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			System.out.println("�Se termin� el tiempo!\n");

			for (int i = 0; i < caballos.length; i++)
				System.out.println("Ganaste " + caballos[i] + " de dinero por el " + (i + 1) + " caballo.");
		}

		public void nuevoSegundo() {
			for (int i = 0; i < caba.length; i++)
				caba[i].correr();
			
			for (ClientThread clt : clientes) {
				clt.outConnection.println(caba[0].distancia + "-" + caba[1].distancia + "-" + caba[2].distancia + "-"
						+ caba[3].distancia + "-" + caba[4].distancia + "-" + caba[5].distancia);
			}

		}
	}
	
	static class ServerUDP extends Thread{
		
		private AudioUDPServer server;
		//private AudioUDPClient client;
		@Override
		public void run(){
			
			while (seconds < 180) {
				try {
					Thread.sleep(1000);
					seconds++;
					server= new AudioUDPServer();
					//client= new AudioUDPClient();
				
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		
		}
	}
	
	
	

	static class caballo {

		
		int distancia = 0;

		public void correr() {
			distancia += rdm.nextInt(3);
		}

	}

	static class ClientThread extends Thread {

		Socket client;
		BufferedReader inConnection;
		PrintWriter outConnection;

		public ClientThread(Socket client) {

			this.client = client;
			try {
				inConnection = new BufferedReader(new InputStreamReader(client.getInputStream()));
				outConnection = new PrintWriter(client.getOutputStream(), true);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		@Override
		public void run() {

			try {
				// Mientras no hayan pasado los 3 minutos
				while (seconds < 180) {
					if (inConnection.ready()) {
						String comando = inConnection.readLine();
						if (comando.startsWith("apuesto por")) {
							String[] array = comando.split(":");
							double dinero = Double.parseDouble(array[1]);
							int caballo = Integer.parseInt(array[0].split(" ")[2]);
							apostar(caballo, dinero);
						}
					}
				}

				client.close();
				inConnection.close();
				outConnection.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}
