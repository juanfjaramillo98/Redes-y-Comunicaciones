import java.util.*;
import java.net.*;
import java.io.*;
import java.lang.reflect.GenericArrayType;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.net.ssl.SSLSocketFactory;
import javax.sound.sampled.SourceDataLine;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextArea;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JScrollPane;

public class Client {
	private JFrame frame;
	private JProgressBar progressBar_c1;
	private JProgressBar progressBar_c2;
	private JProgressBar progressBar_c3;
	private JProgressBar progressBar_c4;
	private JProgressBar progressBar_c5;
	private JProgressBar progressBar_c6;
//private static AudioUDPClient audio;
	static final String TRUSTSTORE_LOCATION = "/Apuesta de Caballos/jks/truststore.jks";
	static SourceDataLine sourceDataLine;
	static SSLSocketFactory socketFactory;
	public Client() {
		initialize();
//audio= new AudioUDPClient();
	}

	public void initialize() {

		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 450, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		progressBar_c1 = new JProgressBar();
		progressBar_c1.setMaximum(180);
		progressBar_c2 = new JProgressBar();
		progressBar_c2.setMaximum(180);
		progressBar_c3 = new JProgressBar();
		progressBar_c3.setMaximum(180);
		progressBar_c4 = new JProgressBar();
		progressBar_c4.setMaximum(180);
		progressBar_c5 = new JProgressBar();
		progressBar_c5.setMaximum(180);
		progressBar_c6 = new JProgressBar();
		progressBar_c6.setMaximum(180);
		final JLabel lblNewLabel_c1 = new JLabel("1.Pegaso");
		final JLabel lblNewLabel_c2 = new JLabel("2.Hackerson");
		final JLabel lblNewLabel_c3 = new JLabel("3.Aristoteles");
		final JLabel lblNewLabel_c4 = new JLabel("4.Messi");
		final JLabel lblNewLabel_c5 = new JLabel("5.Dante");
		final JLabel lblNewLabel_c6 = new JLabel("6.Mbappe");

	
		

		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(Alignment.LEADING).addGroup(groupLayout
				.createSequentialGroup().addContainerGap()
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
//								.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 424, Short.MAX_VALUE)
								.addContainerGap())
						.addGroup(
								groupLayout.createSequentialGroup()
										.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
												.addComponent(lblNewLabel_c3)
												.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
														.addComponent(lblNewLabel_c1)

														.addComponent(lblNewLabel_c4).addComponent(lblNewLabel_c5)
														.addComponent(lblNewLabel_c6).addComponent(lblNewLabel_c2)))
										.addPreferredGap(ComponentPlacement.UNRELATED)
										.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
//												.addComponent(btnEmpezar, Alignment.LEADING, GroupLayout.DEFAULT_SIZE,
//														221, Short.MAX_VALUE)
												.addComponent(progressBar_c2, Alignment.LEADING,
														GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
												.addComponent(progressBar_c3, Alignment.LEADING,
														GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
												.addComponent(progressBar_c4, Alignment.LEADING,
														GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
												.addComponent(progressBar_c5, Alignment.LEADING,
														GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
												.addComponent(progressBar_c6, Alignment.LEADING,
														GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
												.addComponent(progressBar_c1, Alignment.LEADING,
														GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE))
										.addGap(127))
						.addGroup(groupLayout.createSequentialGroup()
								
								.addContainerGap(328, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
								
								.addContainerGap(366, Short.MAX_VALUE)))));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(Alignment.LEADING).addGroup(groupLayout
				.createSequentialGroup().addGap(13)
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(progressBar_c1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_c1))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING).addComponent(lblNewLabel_c2).addComponent(
						progressBar_c2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
						GroupLayout.PREFERRED_SIZE))
				.addPreferredGap(ComponentPlacement.RELATED)
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(progressBar_c3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_c3))
				.addPreferredGap(ComponentPlacement.RELATED)

				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(progressBar_c4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_c4))
				.addPreferredGap(ComponentPlacement.RELATED)

				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(progressBar_c5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_c5))
				.addPreferredGap(ComponentPlacement.RELATED)

				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(progressBar_c6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
								GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_c6))
				.addPreferredGap(ComponentPlacement.RELATED)

//				.addComponent(btnEmpezar).addPreferredGap(ComponentPlacement.RELATED)
//				.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 361, GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(ComponentPlacement.RELATED)
				
				.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				
				.addContainerGap()));
		groupLayout.linkSize(SwingConstants.VERTICAL, new Component[] { progressBar_c1, progressBar_c2, progressBar_c3,
				progressBar_c4, progressBar_c5, progressBar_c6 });

		frame.getContentPane().setLayout(groupLayout);



	}

	public JProgressBar getProgressBar_c1() {
		return progressBar_c1;
	}

	public void setProgressBar_c1(JProgressBar progressBar_c1) {
		this.progressBar_c1 = progressBar_c1;
	}

	public JProgressBar getProgressBar_c2() {
		return progressBar_c2;
	}

	public void setProgressBar_c2(JProgressBar progressBar_c2) {
		this.progressBar_c2 = progressBar_c2;
	}

	public JProgressBar getProgressBar_c3() {
		return progressBar_c3;
	}

	public void setProgressBar_c3(JProgressBar progressBar_c3) {
		this.progressBar_c3 = progressBar_c3;
	}

	public JProgressBar getProgressBar_c4() {
		return progressBar_c4;
	}

	public void setProgressBar_c4(JProgressBar progressBar_c4) {
		this.progressBar_c4 = progressBar_c4;
	}

	public JProgressBar getProgressBar_c5() {
		return progressBar_c5;
	}

	public void setProgressBar_c5(JProgressBar progressBar_c5) {
		this.progressBar_c5 = progressBar_c5;
	}

	public JProgressBar getProgressBar_c6() {
		return progressBar_c6;
	}

	public void setProgressBar_c6(JProgressBar progressBar_c6) {
		this.progressBar_c6 = progressBar_c6;
	}
	
	
static class ServerUDP extends Thread{
		
		private AudioUDPClient server;
		//private AudioUDPClient client;
		public void run(){
			
			
				try {
					Thread.sleep(1000);
					
					server= new AudioUDPClient();
					//client= new AudioUDPClient();
				
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			
		
		}
	}
	
	public void refrescar(int[]array) {
		progressBar_c1.setValue(array[0]);
		progressBar_c2.setValue(array[1]);
		progressBar_c3.setValue(array[2]);
		progressBar_c4.setValue(array[3]);
		progressBar_c5.setValue(array[4]);
		progressBar_c6.setValue(array[5]);
		
	}

	public static void main(String[] args) {
		
		System.setProperty("javax.net.ssl.trustStore", TRUSTSTORE_LOCATION);
		socketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
		Client window = new Client();
		ServerUDP serv = new ServerUDP();
			serv.start();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					window.frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		try {
			//Socket connection = socketFactory.createSocket("localhost", 1248);
			BufferedReader console = new BufferedReader(new InputStreamReader(System.in));

			Socket connection = new Socket("localhost", 1284);
			BufferedReader inConnection = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			PrintWriter outConnection = new PrintWriter(connection.getOutputStream(), true);

			System.out.println("Conectado con casa de apuestas.");
			System.out.println(
					"Para apostar por uno de los 6 caballos debe hacerlo as�:\napuesto por <numero de caballo>:<dinero a apostar>");

			String comando = "";
			boolean aposto=false;
		//	audio= new AudioUDPClient();
			while (!comando.equals("cerrar")) {
				
				if (console.ready() && !aposto) {
					comando = console.readLine();
					if (comando.startsWith("apuesto por")) {
						aposto=true;
						String[] array = comando.split(":");
						double dinero = Double.parseDouble(array[1]);
						int caballo = Integer.parseInt(array[0].split(" ")[2]);
						outConnection.println(comando);
						System.out.println(caballo + "");
						
						if (caballo == 1) {
							window.getProgressBar_c1().setBackground(Color.RED);
						} else if (caballo == 2) {
							window.getProgressBar_c2().setBackground(Color.RED);
						} else if (caballo == 3) {
							window.getProgressBar_c3().setBackground(Color.RED);
						} else if (caballo == 4) {
							window.getProgressBar_c4().setBackground(Color.RED);
						} else if (caballo == 5) {
							window.getProgressBar_c5().setBackground(Color.RED);
						} else if (caballo == 6) {
							window.getProgressBar_c6().setBackground(Color.RED);
						} else {
							window.getProgressBar_c1().setBackground(Color.RED);
						}
					}
				}
				
				if(inConnection.ready())
				{
					comando = inConnection.readLine();
					String[] distanciaActual = comando.split("-");
					int uno = Integer.parseInt(distanciaActual[0]);
					int dos = Integer.parseInt(distanciaActual[1]);
					int tres = Integer.parseInt(distanciaActual[2]);
					int cuatro = Integer.parseInt(distanciaActual[3]);
					int cinco = Integer.parseInt(distanciaActual[4]);
					int seis = Integer.parseInt(distanciaActual[5]);
					window.refrescar(new int[] {uno, dos, tres, cuatro, cinco, seis});
				}			
				
			}

			inConnection.close();
			outConnection.close();
			connection.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
